How to run the Employee Management System (empms) Project

1. Download the  zip file

2. Extract the file and copy empms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name empmsdb

6. Import empmsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/empms (frontend)



Credential for admin panel :

Username: admin@gmail.com
Password: Test@12345



Credential for  Employee panel :

Employee Email: ak234@test.com
Password: Test@123
Or Register a new Employee.